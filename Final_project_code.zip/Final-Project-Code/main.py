import cv2
import time
import datetime
import numpy as np
import os
import pandas as pd
from ultralytics import YOLO

# ---------------- CONFIG ----------------
VIDEO_SOURCE =0#data/videos/sample_highway.mp4"  # 0 for webcam, or "data/videos/sample_highway.mp4"
CONF_THRESHOLD = 0.4
IOU_MATCH_THRESHOLD = 0.3
SPEED_SMOOTH_FRAMES = 5
ACCIDENT_SPEED_THRESHOLD = 8.0      # pixels/sec (approx)
ACCIDENT_MIN_STILL_FRAMES = 15      # itne frames tak still + overlap
EVENT_LOG_PATH = "data/logs/events.csv"
ALERT_DISPLAY_SECONDS = 8   # accident ke baad kitne sec tak alert dikhana hai


# Simulation mode (for synthetic video)
SIMULATION_MODE = False #True             # synthetic ke liye True, webcam ke liye False
CRASH_FRAME = 200                  # synthetic crash frame

# Accident heuristics (for real videos)
PER_VEHICLE_SPEED_DROP = 0.4       # 60% se zyada sudden speed drop
GLOBAL_SPEED_DROP_THRESHOLD = 0.3  # avg speed me 50% se zyada drop
MIN_TRACKS_FOR_GLOBAL = 2          # kam se kam 2 vehicles hon to global check

# Vehicle classes (COCO)
VEHICLE_CLASSES = ["car", "truck", "bus", "motorbike", "motorcycle"]

# ----------------------------------------


class SimpleTracker:
    """
    Simple IoU based tracker:
    - Har detection ko ek ID deta hai
    - Previous frame ke bounding boxes se IoU max lekar match karta hai
    - Position history se approx speed nikalta hai
    - prev_speed store karta hai (speed drop detect karne ke liye)
    """

    def __init__(self):
        self.next_id = 1
        self.tracks = {}  # id -> dict with bbox, history, still_frames, speed, prev_speed

    def iou(self, boxA, boxB):
        xA = max(boxA[0], boxB[0])
        yA = max(boxA[1], boxB[1])
        xB = min(boxA[2], boxB[2])
        yB = min(boxA[3], boxB[3])

        interW = max(0, xB - xA)
        interH = max(0, yB - yA)
        interArea = interW * interH

        boxAArea = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
        boxBArea = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])

        union = boxAArea + boxBArea - interArea
        if union == 0:
            return 0.0
        return interArea / union

    def update(self, detections, dt):
        """
        detections: list of (x1, y1, x2, y2, cls_name, conf)
        dt: time between frames (seconds)
        """
        track_ids = list(self.tracks.keys())
        prev_boxes = [self.tracks[tid]["bbox"] for tid in track_ids]

        assigned_tracks = set()
        updated_tracks = {}

        for det in detections:
            box = det[:4]
            cls_name = det[4]
            conf = det[5]

            best_iou = 0
            best_id = None
            for tid, pbox in zip(track_ids, prev_boxes):
                if tid in assigned_tracks:
                    continue
                iou_val = self.iou(box, pbox)
                if iou_val > best_iou:
                    best_iou = iou_val
                    best_id = tid

            if best_iou > IOU_MATCH_THRESHOLD and best_id is not None:
                track = self.tracks[best_id]
                prev_cx, prev_cy = track["center"]
                cx = int((box[0] + box[2]) / 2)
                cy = int((box[1] + box[3]) / 2)

                dist = np.sqrt((cx - prev_cx) ** 2 + (cy - prev_cy) ** 2)
                inst_speed = dist / dt if dt > 0 else 0.0

                # Smooth speed history
                track["speed_history"].append(inst_speed)
                if len(track["speed_history"]) > SPEED_SMOOTH_FRAMES:
                    track["speed_history"].pop(0)

                smoothed_speed = float(np.mean(track["speed_history"]))

                # still frames counter
                if smoothed_speed < ACCIDENT_SPEED_THRESHOLD:
                    track["still_frames"] += 1
                else:
                    track["still_frames"] = 0

                # prev_speed ko update karte waqt store karein
                prev_speed = track["speed"]
                track.update(
                    {
                        "bbox": box,
                        "center": (cx, cy),
                        "cls": cls_name,
                        "conf": conf,
                        "prev_speed": prev_speed,
                        "speed": smoothed_speed,
                    }
                )

                updated_tracks[best_id] = track
                assigned_tracks.add(best_id)
            else:
                # New track
                cx = int((box[0] + box[2]) / 2)
                cy = int((box[1] + box[3]) / 2)
                tid = self.next_id
                self.next_id += 1
                updated_tracks[tid] = {
                    "bbox": box,
                    "center": (cx, cy),
                    "cls": cls_name,
                    "conf": conf,
                    "speed": 0.0,
                    "prev_speed": 0.0,
                    "speed_history": [],
                    "still_frames": 0,
                }

        self.tracks = updated_tracks
        return self.tracks


def boxes_overlap(boxA, boxB, min_iou=0.05):
    # simple overlap check
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])

    interW = max(0, xB - xA)
    interH = max(0, yB - yA)
    interArea = interW * interH

    return interArea > 0


def ensure_log_file():
    os.makedirs(os.path.dirname(EVENT_LOG_PATH), exist_ok=True)
    if not os.path.exists(EVENT_LOG_PATH):
        df = pd.DataFrame(
            columns=["timestamp", "frame_no", "event_type", "disruption_score"]
        )
        df.to_csv(EVENT_LOG_PATH, index=False)


def log_event(frame_no, event_type, disruption_score):
    ensure_log_file()
    ts = datetime.datetime.now().isoformat()
    df = pd.DataFrame(
        [
            {
                "timestamp": ts,
                "frame_no": frame_no,
                "event_type": event_type,
                "disruption_score": disruption_score,
            }
        ]
    )
    df.to_csv(EVENT_LOG_PATH, mode="a", header=False, index=False)


def compute_disruption_score(tracks, frame_area):
    """
    Very simple heuristic:
    - area_ratio = total vehicle area / frame area
    - avg_speed = mean speed of all vehicles
    - High area_ratio + low avg_speed -> high disruption
    Returns score 0-100
    """
    if frame_area <= 0 or len(tracks) == 0:
        return 0

    total_area = 0
    speeds = []
    for tid, tr in tracks.items():
        x1, y1, x2, y2 = tr["bbox"]
        area = max(0, (x2 - x1)) * max(0, (y2 - y1))
        total_area += area
        speeds.append(tr["speed"])

    area_ratio = total_area / frame_area
    avg_speed = float(np.mean(speeds)) if speeds else 0.0

    # normalize roughly
    # assume meaningful area_ratio in [0, 0.5], avg_speed in [0, 80] pixels/s
    area_score = min(1.0, area_ratio / 0.5)
    speed_score = 1.0 - min(1.0, avg_speed / 80.0)

    raw_score = 0.6 * area_score + 0.4 * speed_score
    return int(raw_score * 100)


def main():
    manual_accident_triggered = False

    # Load YOLO model
    print("Loading YOLOv8 model...")
    model = YOLO("yolov8n.pt")  # nano model for speed

    cap = cv2.VideoCapture(VIDEO_SOURCE)
    if not cap.isOpened():
        print("Could not open video source:", VIDEO_SOURCE)
        return

    tracker = SimpleTracker()
    prev_time = time.time()
    frame_no = 0
    last_accident_time = 0
    ACCIDENT_COOLDOWN = 10  # seconds between logging repeated accidents
    prev_global_speed = None
    last_accident_info = None   # dict: {"time": "...", "frame": ..., "score": ...}


    while True:
        ret, frame = cap.read()
        if not ret:
            print("Video stream ended.")
            break

        frame_no += 1
        now = time.time()
        dt = now - prev_time
        prev_time = now

        h, w = frame.shape[:2]
        frame_area = h * w

        # Run detection
        results = model.predict(
            source=frame, conf=CONF_THRESHOLD, verbose=False, imgsz=640
        )

        detections = []
        for r in results:
            boxes = r.boxes
            for b in boxes:
                cls_id = int(b.cls[0])
                cls_name = model.names[cls_id]
                if cls_name not in VEHICLE_CLASSES:
                    continue
                x1, y1, x2, y2 = map(int, b.xyxy[0].tolist())
                conf = float(b.conf[0])
                detections.append((x1, y1, x2, y2, cls_name, conf))

        tracks = tracker.update(detections, dt)

        # Average global speed (sirf real detection ke liye)
        speeds_all = [tr["speed"] for tr in tracks.values() if tr["speed"] > 0]
        avg_global_speed = float(np.mean(speeds_all)) if speeds_all else 0.0

        # ---------------- ACCIDENT DETECTION ----------------
        accident_detected = False
        accident_pairs = []
        accident_ids = set()

        ids = list(tracks.keys())

        # 1) Old rule: overlapping + still for many frames (synthetic / clear cases)
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                t1 = tracks[ids[i]]
                t2 = tracks[ids[j]]
                box1 = t1["bbox"]
                box2 = t2["bbox"]

                if not boxes_overlap(box1, box2):
                    continue

                if (
                    t1["still_frames"] > ACCIDENT_MIN_STILL_FRAMES
                    and t2["still_frames"] > ACCIDENT_MIN_STILL_FRAMES
                ):
                    accident_detected = True
                    accident_pairs.append((box1, box2))
                    accident_ids.add(ids[i])
                    accident_ids.add(ids[j])

        # 2) Per-vehicle sudden speed drop (works better on real crash clips)
        for tid, tr in tracks.items():
            prev_s = tr.get("prev_speed", 0.0) and len(tracks) >= MIN_TRACKS_FOR_GLOBAL
            cur_s = tr["speed"]
            if prev_s > 0 and cur_s < ACCIDENT_SPEED_THRESHOLD:
                drop_ratio = (prev_s - cur_s) / prev_s
                if drop_ratio > PER_VEHICLE_SPEED_DROP:
                    accident_detected = True
                    accident_ids.add(tid)

        # 3) Global sudden slowdown (many vehicles suddenly slow down)
        if (
            prev_global_speed is not None
            and prev_global_speed > 0
            and avg_global_speed < ACCIDENT_SPEED_THRESHOLD
            and len(tracks) >= MIN_TRACKS_FOR_GLOBAL
        ):
            drop_glob = (prev_global_speed - avg_global_speed) / prev_global_speed
            if drop_glob > GLOBAL_SPEED_DROP_THRESHOLD:
                accident_detected = True
                for tid in tracks.keys():
                    accident_ids.add(tid)
        
        # manual trigger se accident force karne ke liye
        if manual_accident_triggered:
            accident_detected = True


        # update global speed memory
        prev_global_speed = avg_global_speed

        # ---------------- DISRUPTION SCORE ----------------
        disruption_score = compute_disruption_score(tracks, frame_area)

        # Simulation fallback (synthetic video ke liye)
        if SIMULATION_MODE and len(tracks) == 0:
            if frame_no < CRASH_FRAME:
                # crash se pehle normal traffic
                disruption_score = min(40, frame_no // 5)
            else:
                # crash ke baad disruption fast badhta hai
                disruption_score = min(100, 40 + (frame_no - CRASH_FRAME) // 2)

        # ---------------- LOGGING ----------------
        # Logging accident event (with cooldown)
                # ---------------- LOGGING ----------------
        # Logging accident event (with cooldown)
        if accident_detected and (now - last_accident_time) > ACCIDENT_COOLDOWN:
            accident_time_str = datetime.datetime.now().strftime("%H:%M:%S")

            print(
                f"[EVENT] Accident detected at {accident_time_str}, "
                f"frame {frame_no}, disruption_score={disruption_score}"
            )

            # CSV me log
            log_event(frame_no, "ACCIDENT", disruption_score)

            # Screen pe dikhane ke liye info store
            last_accident_info = {
                "time": accident_time_str,
                "frame": frame_no,
                "score": disruption_score,
            }

            # (Optional) terminal beep – kuch systems pe sound aayega
            print("\a")

            last_accident_time = now


        # ---------------- DRAWING ----------------
        # Draw results
        for tid, tr in tracks.items():
            x1, y1, x2, y2 = tr["bbox"]
            speed = tr["speed"]
            cls_name = tr["cls"]

            # agar yeh vehicle accident_ids me hai to red box karo
            if tid in accident_ids:
                color = (0, 0, 255)   # RED
            else:
                color = (0, 255, 0)   # GREEN

            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            label = f"ID {tid} {cls_name} v={speed:.1f}"
            cv2.putText(
                frame,
                label,
                (x1, max(0, y1 - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                color,
                1,
                cv2.LINE_AA,
            )

        # Highlight accident pairs (extra visual)
        for box1, box2 in accident_pairs:
            cx = int((box1[0] + box1[2] + box2[0] + box2[2]) / 4)
            cy = int((box1[1] + box1[3] + box2[1] + box2[3]) / 4)
            cv2.circle(frame, (cx, cy), 25, (0, 0, 255), 3)
            cv2.putText(
                frame,
                "ACCIDENT",
                (cx - 40, cy - 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )

        # Put disruption score text
        cv2.rectangle(frame, (10, 10), (360, 80), (0, 0, 0), -1)
        cv2.putText(
            frame,
            f"Traffic Disruption: {disruption_score}/100",
            (20, 55),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )

        if accident_detected:
            cv2.putText(
                frame,
                "POSSIBLE ACCIDENT / SUDDEN SLOWDOWN",
                (20, 100),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
                # Last accident info overlay (few seconds tak alert)
        if last_accident_info is not None and (now - last_accident_time) < ALERT_DISPLAY_SECONDS:
            cv2.rectangle(frame, (10, 110), (400, 190), (0, 0, 0), -1)
            cv2.putText(
                frame,
                "ALERT: ACCIDENT DETECTED",
                (20, 140),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            cv2.putText(
                frame,
                f"Time: {last_accident_info['time']}",
                (20, 170),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                1,
                cv2.LINE_AA,
            )
            # (optional aur line)
            # cv2.putText(
            #     frame,
            #     f"Score: {last_accident_info['score']}",
            #     (220, 170),
            #     cv2.FONT_HERSHEY_SIMPLEX,
            #     0.5,
            #     (255, 255, 255),
            #     1,
            #     cv2.LINE_AA,
            # )


        cv2.imshow("AI Accident & Traffic Monitoring", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == 27 or key == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
