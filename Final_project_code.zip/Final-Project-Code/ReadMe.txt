This folder contains only the main source code files.
The model weights and data files are included separately in the Resources_and_Models.zip.
To run:
1) Install dependencies: pip install -r requirements.txt
2) Run main.py to start detection.
