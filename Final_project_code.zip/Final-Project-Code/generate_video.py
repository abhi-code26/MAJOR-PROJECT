import cv2
import numpy as np
import random

W, H = 1280, 720
FPS = 20
DURATION = 20
OUT = "data/videos/sample_highway.mp4"

fourcc = cv2.VideoWriter_fourcc(*"mp4v")
out = cv2.VideoWriter(OUT, fourcc, FPS, (W, H))

# Colors
ROAD = (50, 50, 50)
LANE = (255, 255, 255)
CAR_COLORS = [(255,0,0),(0,255,0),(0,0,255),(255,255,0),(255,165,0)]

# Cars
cars = []
for i in range(6):
    cars.append({
        "x": random.randint(0, W),
        "y": random.choice([270,310,350,390,430]),
        "vx": random.choice([4,5,6,-4,-5]),
        "color": random.choice(CAR_COLORS)
    })

accident_frame = FPS * 10

for frame_no in range(FPS * DURATION):
    frame = np.zeros((H, W, 3), dtype=np.uint8)

    # ROAD
    cv2.rectangle(frame, (0, 230), (W, 500), ROAD, -1)

    # LANE LINES
    for y in [300, 340, 380, 420]:
        cv2.line(frame, (0, y), (W, y), LANE, 2)

    for i, car in enumerate(cars):
        car["x"] += car["vx"]

        # wrap around
        if car["x"] > W: car["x"] = -80
        if car["x"] < -80: car["x"] = W

        # Accident simulation
        if frame_no == accident_frame and i < 2:
            cars[0]["vx"] = 0
            cars[1]["vx"] = 0
            cars[1]["x"] = cars[0]["x"] + 20

        # Draw car (car shape better)
        x, y = int(car["x"]), int(car["y"])
        cv2.rectangle(frame, (x, y), (x+70, y+30), car["color"], -1)
        cv2.circle(frame, (x+15, y+30), 6, (0,0,0), -1)
        cv2.circle(frame, (x+55, y+30), 6, (0,0,0), -1)

    # Accident text flash
    if frame_no > accident_frame:
        cv2.putText(frame, "CRASH OCCURRED",
                    (460, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 1,
                    (0,0,255), 3)

    out.write(frame)

out.release()
print("✅ Realistic traffic video generated at:", OUT)
